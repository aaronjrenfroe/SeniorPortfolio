/**
 * Created by trial on 3/24/2017.
 */
public enum Players {
    PLAYER1, PLAYER2, NOPLAYER
}
